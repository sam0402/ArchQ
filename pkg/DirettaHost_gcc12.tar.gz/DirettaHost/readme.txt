
Synchro Sync Alsa

Do not make any discriminatory remarks regarding human rights, nationality, gender, or language
Do not make any critical remarks about previews
No such behavior in the past.
In case of violation, Diretta will not support all products.

Previews are not always stable.
Information is constantly changing
Developers often make mistakes.
Not for commercial use, not for redistribution


[build install]
./rewrite.sh  [ARCH NAME]

[test]
modprobe snd_pcm
insmod xxxx/driver/alsa_bridge.ko
xxxx/ssyncAlsa [config file name] [product unique name]

[example] : multi target ,  target profile 
sudo ssyncAlsa_XXXXXXX setting.inf


[Receive logs]
logcatch


[install]

#copy systemd service
sudo cp ./diretta_bridge_driver.service /etc/systemd/system
sudo cp ./diretta_ssync_host.service /etc/systemd/system

#enable systemd service
sudo systemctl enable diretta_bridge_driver
sudo systemctl enable diretta_ssync_host

reboot after can user Diretta Host


[setting]

ThredMode
	Critcal=1
	NoShotrSleep=2
	NoSleep4Core=4
	SocketNoBlock=8
	OccupiedCPU=16
	FEEDBACK=32,64,128(moving average)
	NOFASTFEEDBACK=256
	IDLEONE=512
	IDLEALL=1024
	NOSLEEPFORCE=2048
	
InfoCycle
	Information Packet Cycle Time microsecond

TargetProfileLimitTime
	Target Profile using 0=SelfProfile other=LimitCycleTime
		it profile is automatically change for your system.
		If diretta drops process to high load then, fall down to light diretta processing.
		
FlexCycle
	diable is Fix Cylemode
	enable is Flex Cyclemode
	random is Random Cyclemode

CycleTime
	Transfer Packet Cycle Maximum Time microsecond

CycleMinTime
	Transfer Packet Cycle Minimum Time microsecond
	onry random mode

 (only grobale)
Debug
	disable not output
	enable is put out debug message to logcatch
	stdout is put out debug message to logcatch/stdout
Interface
	connect interface lits sepalete(,)  eth1,eth2 
periodMax
	alsa buffer period max
periodMin
	alsa buffer period min
periodSizeMax
	alsa buffer size max
periodSizeMin
	alsa buffer size min
(minimumsize = periodMin*periodSizeMin )
(maxmumsie = periodMin*periodSizeMax )
CpuSend
	Use with OccupiedCPU(ThredMode 16)
	Fixes the CPU used by the send thread.
	Range setting.
	XX-XX (0-3  CPU 0,1,2,3
	From among them, the transmission thread is assigned to the open CPU.
CpuOther
	Use with OccupiedCPU(ThredMode 16)
	Fixes the CPU used for non send threads.
	Range setting.
	XX-XX (0-3  CPU 0,1,2,3
	Assign threads to those CPUs.
	
syncBufferCount
	Buffer count between ALSA Bridge and packet transmission
	How many of the specified periodSizen will be allocated as a buffer when the player app opens ALSA
	default 8		
	
alsaUnderrun
	Silent transport when buffer underrun occurs due to player app write delay.
	In the case of DISABLE, recovery may be difficult due to continued playback
	default enable
	
unInitMemDet
	If the same content is written from the application to alsa, the part is replaced by mute.
	It cannot be a complete solution for uninitialized memory.
	Problem inherently solved by the player.

LatencyBuffer
	Try to change the buffer size of Target
	If 0, Target's standard time is used.
	Time microsecond
	
inf group
[global] or none
	defalt profile

[XXXX] 
	XXXX = TargetName
	custum Target profile
